
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "keyword_test_demo.Amazon_Signin.checkDropElementKatalon"(
    	TestObject object	
     , 	String option	) {
    (new keyword_test_demo.Amazon_Signin()).checkDropElementKatalon(
        	object
         , 	option)
}
