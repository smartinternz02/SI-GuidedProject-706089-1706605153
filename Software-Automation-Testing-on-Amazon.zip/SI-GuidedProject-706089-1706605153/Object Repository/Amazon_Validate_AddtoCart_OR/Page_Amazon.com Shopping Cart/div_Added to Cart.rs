<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Added to Cart</name>
   <tag></tag>
   <elementGuidId>13de5918-5f98-4393-a369-27b5f32f60ce</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sw-atc-details-single-container']/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-padding-medium.sw-atc-message-section</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>27c954d9-e171-4458-a551-376b42629f05</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-section a-padding-medium sw-atc-message-section</value>
      <webElementGuid>4648d592-255e-4568-ac48-9cccf018be01</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
    
    
    
    
    
    
</value>
      <webElementGuid>01f01ea8-b848-40c5-aab6-91b3561ab2b7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sw-atc-details-single-container&quot;)/div[@class=&quot;a-section a-padding-medium sw-atc-message-section&quot;]</value>
      <webElementGuid>3b06c342-8625-4f90-808f-cef3db6d4bc7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sw-atc-details-single-container']/div[2]</value>
      <webElementGuid>18a3b302-24fe-45fb-bcbe-4e3263e838a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='+'])[2]/following::div[2]</value>
      <webElementGuid>a3569d8e-46f6-4e3e-be3e-16a8be1117f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='+'])[1]/following::div[4]</value>
      <webElementGuid>a76b7590-3090-4075-b99d-4e60657df563</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cart Subtotal:'])[1]/preceding::div[8]</value>
      <webElementGuid>cade0765-de84-4f87-808c-3ae23d4b5111</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div[2]</value>
      <webElementGuid>b48e393e-e866-4910-96ac-a9924d9134c9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
    
    
    
    
    
    
' or . = '
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
    
    
    
    
    
    
')]</value>
      <webElementGuid>3b6f09a8-7e8a-4884-a6f9-884a7865684d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
