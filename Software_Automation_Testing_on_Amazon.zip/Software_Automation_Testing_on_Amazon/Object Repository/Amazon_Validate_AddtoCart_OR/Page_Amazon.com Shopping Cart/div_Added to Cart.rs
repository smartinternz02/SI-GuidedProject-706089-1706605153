<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Added to Cart</name>
   <tag></tag>
   <elementGuidId>e942e699-2a17-4dc8-abdc-deea4adc7f53</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='sw-atc-details-single-container']/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.a-section.a-padding-medium.sw-atc-message-section</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>656df8d7-906b-46be-adcd-62d46f4cecce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-section a-padding-medium sw-atc-message-section</value>
      <webElementGuid>bfb9a208-3d03-4910-9dd2-35b1f1125e95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
    
    
    
    
    
    
</value>
      <webElementGuid>30396b86-bcf4-46be-93dd-9ec70e8c2adf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sw-atc-details-single-container&quot;)/div[@class=&quot;a-section a-padding-medium sw-atc-message-section&quot;]</value>
      <webElementGuid>cac3cda2-a317-48f8-bd6d-06194484bb51</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='sw-atc-details-single-container']/div[2]</value>
      <webElementGuid>0a6c04de-8e29-41c1-ac59-a6c9de4e7cfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='+'])[2]/following::div[2]</value>
      <webElementGuid>d2dbffac-7601-4076-89ba-fca8bf02d8ba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='+'])[1]/following::div[4]</value>
      <webElementGuid>141a6b0b-d184-411e-90e0-0b51190250ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Cart Subtotal:'])[1]/preceding::div[8]</value>
      <webElementGuid>88267e8d-50d8-42a0-98c9-42f9732e3796</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div[2]</value>
      <webElementGuid>85bb15d0-aaf2-452c-9d4d-72f54c823b3c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
    
    
    
    
    
    
' or . = '
    
        
            

















    
    

    
        
            Added to Cart
        
    


        
        
    
    
    
    
    
    
    
    
')]</value>
      <webElementGuid>ff17ad7b-3fde-427f-9552-01c947481af5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
