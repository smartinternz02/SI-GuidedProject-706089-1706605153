<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Touchscreen 15.6 Vivobook Business Lap_85f7b8</name>
   <tag></tag>
   <elementGuidId>3098d725-5f58-4da5-bdae-6b129f257b6a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='search']/div/div/div/span/div/div[2]/div/div/div/div/span/div/div/div/div[2]/div/div/div/h2/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span.a-size-medium.a-color-base.a-text-normal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>9a6482ba-c53a-439d-b44c-035cbce393d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-size-medium a-color-base a-text-normal</value>
      <webElementGuid>355c0d50-cd09-4f03-aef2-c76d6b9087c7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Touchscreen 15.6'' Vivobook Business Laptop Computer, Windows 11 Pro Laptop 40GB RAM 1TB SSD, Inter Core i7-1255U (10 Core) Processor, FHD 1920x1080 Display, Backlit Keyboard, Wi-Fi 6, Blue</value>
      <webElementGuid>870f992b-3a55-4216-88d9-fdd919a8fae7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;search&quot;)/div[@class=&quot;s-desktop-width-max s-desktop-content s-opposite-dir s-wide-grid-style sg-row&quot;]/div[@class=&quot;sg-col-20-of-24 s-matching-dir sg-col-16-of-20 sg-col sg-col-8-of-12 sg-col-12-of-16&quot;]/div[@class=&quot;sg-col-inner&quot;]/span[@class=&quot;rush-component s-latency-cf-section&quot;]/div[@class=&quot;s-main-slot s-result-list s-search-results sg-row&quot;]/div[@class=&quot;sg-col-20-of-24 s-result-item s-asin sg-col-0-of-12 sg-col-16-of-20 AdHolder sg-col s-widget-spacing-small sg-col-12-of-16&quot;]/div[@class=&quot;sg-col-inner&quot;]/div[@class=&quot;s-widget-container s-spacing-small s-widget-container-height-small celwidget slot=MAIN template=SEARCH_RESULTS widgetId=search-results_1&quot;]/div[@class=&quot;rush-component&quot;]/div[@class=&quot;rush-component s-featured-result-item&quot;]/span[@class=&quot;a-declarative&quot;]/div[@class=&quot;puis-card-container s-card-container s-overflow-hidden aok-relative puis-include-content-margin puis puis-v2ef34xpz4g7e42bsw0vrg0v0gx s-latency-cf-section puis-card-border&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;puisg-row&quot;]/div[@class=&quot;puisg-col puisg-col-4-of-12 puisg-col-8-of-16 puisg-col-12-of-20 puisg-col-12-of-24 puis-list-col-right&quot;]/div[@class=&quot;puisg-col-inner&quot;]/div[@class=&quot;a-section a-spacing-small a-spacing-top-small&quot;]/div[@class=&quot;a-section a-spacing-none puis-padding-right-small s-title-instructions-style&quot;]/h2[@class=&quot;a-size-mini a-spacing-none a-color-base s-line-clamp-2&quot;]/a[@class=&quot;a-link-normal s-underline-text s-underline-link-text s-link-style a-text-normal&quot;]/span[@class=&quot;a-size-medium a-color-base a-text-normal&quot;]</value>
      <webElementGuid>22b40a84-ff3d-48a3-9991-adca13040f4d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='search']/div/div/div/span/div/div[2]/div/div/div/div/span/div/div/div/div[2]/div/div/div/h2/a/span</value>
      <webElementGuid>b3fce99e-1124-4201-a9fa-e3abf1d0159d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ASUS'])[1]/following::span[1]</value>
      <webElementGuid>edfb6701-c96b-4386-9045-875bc63c97b2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Leave ad feedback'])[1]/following::span[2]</value>
      <webElementGuid>09117e8d-2926-49fc-91d3-de220e75aa7d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$749.99'])[1]/preceding::span[1]</value>
      <webElementGuid>dc2fefb7-4dc1-48fb-8718-61b2e65c3177</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='$'])[12]/preceding::span[2]</value>
      <webElementGuid>040d55bf-bf86-4d32-9105-f0c8f8dac5b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h2/a/span</value>
      <webElementGuid>c839260d-a489-4378-9c0d-794da5854803</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = concat(&quot;Touchscreen 15.6&quot; , &quot;'&quot; , &quot;&quot; , &quot;'&quot; , &quot; Vivobook Business Laptop Computer, Windows 11 Pro Laptop 40GB RAM 1TB SSD, Inter Core i7-1255U (10 Core) Processor, FHD 1920x1080 Display, Backlit Keyboard, Wi-Fi 6, Blue&quot;) or . = concat(&quot;Touchscreen 15.6&quot; , &quot;'&quot; , &quot;&quot; , &quot;'&quot; , &quot; Vivobook Business Laptop Computer, Windows 11 Pro Laptop 40GB RAM 1TB SSD, Inter Core i7-1255U (10 Core) Processor, FHD 1920x1080 Display, Backlit Keyboard, Wi-Fi 6, Blue&quot;))]</value>
      <webElementGuid>3a976a8b-7b97-4bf0-847f-d8dea4c2a93b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
