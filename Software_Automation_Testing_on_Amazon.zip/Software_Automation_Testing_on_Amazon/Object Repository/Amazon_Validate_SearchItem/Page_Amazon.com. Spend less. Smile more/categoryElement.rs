<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>categoryElement</name>
   <tag></tag>
   <elementGuidId>0d1a652e-030d-4cc0-9319-7c8c4f90a5f1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>6578bb6d-1370-4b8b-8772-d6be05d33d2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>88135a9b-fe4b-4146-bc6c-770718adbb23</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>368d648c-aa09-4d2e-9412-c008e3ae970a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>k+fyIAyB82R9jVEmroQ0OWwSW3A=</value>
      <webElementGuid>3759f64a-fe44-4eaa-9bc2-31d28013f27f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>0142e617-8075-463a-88f3-77e1a9e65820</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>218444e3-eb71-4695-8bb7-b477a59c794f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>17aa69e4-013a-426e-b899-524da0f6ee80</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>8fa16da9-1ef5-45a5-b0f8-61fedd47151b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>ae8283e2-f354-42a7-903c-9edf2f8cc9ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys' Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls' Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men's Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women's Fashion
    </value>
      <webElementGuid>5d97c999-18a1-4c6b-b695-a9f1915944ac</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>1bb8a617-5d3d-4951-acaa-0634985ad255</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>034dcb09-0698-4128-8423-ed8d2d22de37</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>fb5fae4a-52d3-4fa6-be7b-7973f0198f02</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='All'])[1]/following::select[1]</value>
      <webElementGuid>5faa6a09-e707-4aab-b381-86d18a86e852</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='India'])[1]/following::select[1]</value>
      <webElementGuid>90c6888e-1d93-4155-8a98-12b1d24a1e90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Search Amazon'])[1]/preceding::select[1]</value>
      <webElementGuid>1ccc1bc1-c920-4f70-8242-6501626af538</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='EN'])[1]/preceding::select[1]</value>
      <webElementGuid>13a682a9-2045-4a6c-a7df-3a83608a72b5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>5d1e1fb1-a254-4a93-bb09-469c7222d31e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;) or . = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;))]</value>
      <webElementGuid>2ea8e7cc-3adf-43a0-8adb-937f52a1ac43</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
